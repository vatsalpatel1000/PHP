<?php 
include'dbconnection.php';

error_reporting(E_ERROR | E_PARSE);
//error_reporting(0);    use for hide error 
$Fname="";
if(isset($_POST["submit"]))
{  
    $Fname=$_POST['Fname'];
    $Lname=$_POST["Lname"];
    $Mobileno=$_POST["Mobileno"];
    $Email=$_POST["Email"];
    $Age=$_POST["Age"];
    $Gender=$_POST["Gender"];
    $Subjects=$_POST["Subjects"];
    $Password1=$_POST["Password"];
    $Password=md5($Password1); /// use md for dod show password  

    date_default_timezone_set("Asia/Calcutta");
    $Date= date("m/d/Y h:i:sa");
    echo date("h:i:sa");
    
      

    $item = '';                         /// use this for select multiple check box at a time 
    foreach($Subjects as $items){
      
          $item .=$items .',';
        
    }
      $item1= trim($item,',') ;
 


    //var_dump($_POST);
    //exit;
    //echo "INSERT INTO login (Fame,Lname,Mobileno,Email, Age, Gender,Subjects,Password) VALUES ('$Fname','$Lname','$Mobileno','$Email','$Age','$Gender','$item1','$Password')";
      
   $insert=mysqli_query($conn,"INSERT INTO login (Fname,Lname, Mobileno, Email, Age, Gender, Subjects, Password, Date) VALUES ('$Fname','$Lname','$Mobileno','$Email','$Age','$Gender','$item1','$Password','$Date')");
}

?>


  

<html>    
    <head>    
        <title>Registration Form</title>
    </head>    
    <body onload="Captcha()">
        <link href = "registration.css" type = "text/css" rel = "stylesheet" />    
        <br> <h2>Sign Up for Visit Official Website </h2>    
        <form role="form" name = "" action="" method = "POST" onsubmit="return ValidCaptcha()"  >  
          
            <div class = "container">  

                <div class = "form_group">    
                    <label>Fname:</label>    
                    <input type = "text" name = "Fname" id="Fname" value = "" required />    
                </div>  
                
                <div class = "form_group">    
                    <label>Lname:</label>    
                    <input type = "text" name = "Lname" value = "" required />    
                </div>
                                 
                <div class = "form_group">    
                    <label>Mobileno:</label>    
                    <input type = "text" name = "Mobileno" value = "" id="Mobile No." onkeyup="validatephone(this);" class="form-control input-sm" placeholder="Mobile No. *" Required style="height:30px;">    
                </div>

                <div class = "form_group">    
                    <label>Email</label>    
                    <input type = "text" name = "Email" value = "" required />    
                </div>
                
                <div class = "form_group">    
                    <label>Age:</label>    
                    <input type = "text" name = "Age" value = "" required/>    
                </div>  

                <div class = "form_group">    
                    <label>Gender:</label>                          
                </div>      
                <div class="container">
                    <form>
                        <label class="radio-inline">
                            <input type="radio" value= Male name="Gender" checked>Male  
                        </label>
                                    
                        <label class="radio-inline">
                            <input type="radio" value= Female name="Gender">Female 
                        </label>
    
             
                </div>
                <br>


                <p>Choose Your Subjects:</p>

                <div class="form-group mb-3">
                                <input type="checkbox" name="Subjects[]" value="Database"> Database 
                                <input type="checkbox" name="Subjects[]" value="Operating system"> Operating system 
                                <input type="checkbox" name="Subjects[]" value="Linux"> Linux 
                                <input type="checkbox" name="Subjects[]" value="Networking"> Networking
                                <input type="checkbox" name="Subjects[]" value="Dsa"> Dsa 
                                 
                </div>
                <br>
                <div class = "form_group">    
                    <label>Password:</label>    
                    <input type = "PASSWORD" name = "Password" value = "<?= rand(0,99999)?>" required readonly  />    
                </div>


          
                
                
                    <div>
                        <div>
                            <div>
                                <input type="text" id="mainCaptcha" style="height:30px;" class="wp-form-control wpcf7-text">
                            </div>
                            <input type="button" class="wpcf7-submit button--itzel"  id="refresh" value="Refresh" onclick="Captcha();" />
                        </div>
                        <input type="text" onpaste="return false;" id="txtInput" style="height:30px;" class="wp-form-control wpcf7-text" placeholder="CAPTCHA" required/></div>    
                    </div>
               
                </body>

  
            <input type="submit" name="submit" id='submit' style="background-color:yellow;margin-left:auto;margin-right:auto;display:block;margin-top:22%;margin-bottom:100%">Click me</button> 
        </form>    
    </body>    
</html>






<script>
    function validatephone(phone) 
{
    var maintainplus = '';
    var numval = phone.value
    if ( numval.charAt(0)=='+' )
    {
        var maintainplus = '';
    }
    curphonevar = numval.replace(/[\\A-Za-z!"£$%^&\,*+_={};:'@#~,.Š\/<>?|`¬\]\[]/g,'');
    phone.value = maintainplus + curphonevar;
    var maintainplus = '';
    phone.focus;
}
</script>

<script type="text/javascript">
                function Captcha(){
                    var alpha = new Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
                    var i;
                    for (i=0;i<6;i++){
                      var a = alpha[Math.floor(Math.random() * alpha.length)];
                      var b = alpha[Math.floor(Math.random() * alpha.length)];
                      var c = alpha[Math.floor(Math.random() * alpha.length)];
                      var d = alpha[Math.floor(Math.random() * alpha.length)];
                      var e = alpha[Math.floor(Math.random() * alpha.length)];
                      var f = alpha[Math.floor(Math.random() * alpha.length)];
                      var g = alpha[Math.floor(Math.random() * alpha.length)];
                     }
                   var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' '+ f + ' ' + g;
                   document.getElementById("mainCaptcha").value = code
                 }
                 function ValidCaptcha(){
                     var string1 = removeSpaces(document.getElementById('mainCaptcha').value);
                     var string2 = removeSpaces(document.getElementById('txtInput').value);
                     if (string1 == string2){
                      
                       window.alert("Submit Sucessfully");
                       return true;
                     }
                     else{  
                        window.location.reload();
                        window.alert("Please enter valid Captcha code");
                        return false;
                     }
                 }
                 function removeSpaces(string){
                   return string.split(' ').join('');
                 }


                 /*Validation for form feild*/
                 function validate()
      {
      

        
         if( document.myForm.name.value == "" )
         {
            alert( "Please provide your name!" );
            document.myForm.name.focus() ;
            return false;
         }
                
            
          var email = document.myForm.email.value;  
            atpos = emailID.indexOf("@");
            dotpos = emailID.lastIndexOf(".");
         
            if (atpos < 1 || ( dotpos - atpos < 2 )) 
           {
            alert("Please enter correct email ID")
            document.myForm.email.focus() ;
            return false;
            }
           
         
        
        
         return( true );
      }
         
     </script>
