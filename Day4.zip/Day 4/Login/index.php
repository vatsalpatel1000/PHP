<?php 
    include'dbconnection.php';

  
    if(isset($_POST["submit"]))
    {  
        
        $Username=$_POST['Username'];
        //echo "$Username";
        $Password1=$_POST["Password"];
        $Password=md5($Password1); /// use md5 for hide show password 
     


        //echo "SELECT Username,Password FROM registration WHERE Username = '".$Username."' and Password = '".$Password."'"; exit;

        $sql = "SELECT Email,Password FROM registration WHERE Email = '".$Username."' and Password= '".$Password."'";
        $result = mysqli_query($conn,  $sql);
        if (mysqli_num_rows($result) > 0) {

            echo "record found";

             header("Location: dashboard.php");
            exit;
          
        } else {       
            echo $msg = "Can't Log in";
            exit;
        }
    }
      //  echo $username;



   

    

?>
 

<html>    
<head> 
<style>
    h3 {text-align: center;}
    p {text-align: center;}
    div {text-align: center;}
  
</style>   
    <div>  <title>  LOGIN PAGE  </title>  <div> 

    </head>    
    <body onload="">
        <link href = "registration.css" type = "text/css" rel = "stylesheet" />    
        <h3><p> Login For Visit Official Website </p> </h3>    
        <form role="form" name = "" action="" method = "POST"  >  
          
            <div class = "container">  

                <div class = "form_group">    
                    <label>Username:</label>    
                    <input type = "text" name = "Username" id="Username" value = "" required />    
                </div>  
                <br>

                <div class = "form_group">    
                    <label>Password:</label>    
                    <input type = "type" name = "Password" value = "" required   />    
                </div> 
                
      

  
            <input type="submit" name="submit" id='submit' style="background-color:yellow;margin-left:auto;margin-right:auto;display:block;margin-top:22%;margin-bottom:100%">Click me</button> 
        </form>    
    </body> 
</html>